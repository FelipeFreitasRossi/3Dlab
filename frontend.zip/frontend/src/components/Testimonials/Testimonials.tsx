import { useCallback, useEffect, useRef, useState } from "react";
import { BadgeCheck, Quote, Star } from "lucide-react";
import { usePreferences } from "../../context/usePreferences";
import styles from "./Testimonials.module.css";

interface Testimonial {
  quote: string;
  author: string;
  role: string;
  rating: number;
}

const TESTIMONIAL_KEYS = [1, 2, 3, 4, 5] as const;

function initials(name: string) {
  return name
    .split(" ")
    .map((part) => part[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export function Testimonials() {
  const { t } = usePreferences();

  const items: Testimonial[] = TESTIMONIAL_KEYS.map((n) => ({
    quote: t(`testimonials.quote${n}`),
    author: t(`testimonials.author${n}`),
    role: t(`testimonials.role${n}`),
    rating: 5,
  }));

  const containerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const autoTimerRef = useRef<number | null>(null);
  const rafRef = useRef<number | null>(null);
  const dragRef = useRef({
    active: false,
    startX: 0,
    scrollLeft: 0,
    moved: false,
  });
  const [paused, setPaused] = useState(false);

  /* ============================================================
     Aplica rotação 3D em cada card conforme a distância ao centro.
     ============================================================ */
  const updateTransforms = useCallback(() => {
    const track = trackRef.current;
    const container = containerRef.current;
    if (!track || !container) return;

    const containerRect = container.getBoundingClientRect();
    const centerX = containerRect.left + containerRect.width / 2;
    const maxDist = containerRect.width * 0.55;

    Array.from(track.children).forEach((node) => {
      const el = node as HTMLElement;
      const rect = el.getBoundingClientRect();
      const elCenter = rect.left + rect.width / 2;
      const distance = elCenter - centerX;
      const ratio = Math.max(-1, Math.min(1, distance / maxDist));
      const rotation = -ratio * 26; // ±26 graus
      const scale = 1 - Math.abs(ratio) * 0.12; // 1.0 → 0.88
      const opacity = 1 - Math.abs(ratio) * 0.35;

      el.style.transform = `rotateY(${rotation}deg) scale(${scale})`;
      el.style.opacity = String(opacity);
    });
  }, []);

  /* ============================================================
     Callback de scroll — agrupa atualizações por requestAnimationFrame.
     ============================================================ */
  const onScroll = useCallback(() => {
    if (rafRef.current) return;
    rafRef.current = requestAnimationFrame(() => {
      updateTransforms();
      rafRef.current = null;
    });
  }, [updateTransforms]);

  /* ============================================================
     Auto-advance — desliza um card a cada 4s, volta ao início no fim.
     ============================================================ */
  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    if (paused) return;

    autoTimerRef.current = window.setInterval(() => {
      if (dragRef.current.active) return;

      const card = track.firstElementChild as HTMLElement | null;
      if (!card) return;

      const cardWidth = card.offsetWidth + 20; // 20 = gap
      const maxScroll = track.scrollWidth - track.clientWidth;

      if (track.scrollLeft >= maxScroll - 8) {
        track.scrollTo({ left: 0, behavior: "smooth" });
      } else {
        track.scrollBy({ left: cardWidth, behavior: "smooth" });
      }
    }, 4000);

    return () => {
      if (autoTimerRef.current !== null) {
        window.clearInterval(autoTimerRef.current);
        autoTimerRef.current = null;
      }
    };
  }, [paused]);

  /* ============================================================
     Listeners iniciais + resize.
     ============================================================ */
  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;

    track.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    const timer = window.setTimeout(updateTransforms, 60);

    return () => {
      track.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      window.clearTimeout(timer);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [onScroll, updateTransforms]);

  /* ============================================================
     Drag-to-scroll.
     ============================================================ */
  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const track = trackRef.current;
    if (!track) return;
    if (e.pointerType === "mouse" && e.button !== 0) return;

    dragRef.current = {
      active: true,
      startX: e.clientX,
      scrollLeft: track.scrollLeft,
      moved: false,
    };
    track.setPointerCapture(e.pointerId);
    setPaused(true);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.active) return;
    const track = trackRef.current;
    if (!track) return;

    const dx = e.clientX - dragRef.current.startX;
    if (Math.abs(dx) > 4) dragRef.current.moved = true;
    track.scrollLeft = dragRef.current.scrollLeft - dx;
  };

  const endDrag = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.active) return;
    dragRef.current.active = false;
    const track = trackRef.current;
    if (track) {
      try {
        track.releasePointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    }
    window.setTimeout(() => setPaused(false), 2500);
  };

  return (
    <section className={styles.section}>
      <div className={styles.inner}>
        <div className={styles.header}>
          <p className={styles.eyebrow}>{t("testimonials.eyebrow")}</p>
          <h2 className={styles.title}>{t("testimonials.title")}</h2>
          <p className={styles.subtitle}>{t("testimonials.subtitle")}</p>
        </div>

        <div
          ref={containerRef}
          className={styles.carousel}
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
        >
          <div
            ref={trackRef}
            className={styles.track}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={endDrag}
            onPointerCancel={endDrag}
            onPointerLeave={endDrag}
            role="region"
            aria-label={t("testimonials.title")}
          >
            {items.map((item, index) => (
              <article key={index} className={styles.card}>
                <Quote
                  className={styles.quoteMark}
                  size={72}
                  aria-hidden="true"
                />

                <div
                  className={styles.rating}
                  aria-label={`${item.rating} de 5 estrelas`}
                >
                  {Array.from({ length: item.rating }).map((_, i) => (
                    <Star
                      key={i}
                      size={14}
                      fill="currentColor"
                      strokeWidth={0}
                      aria-hidden="true"
                    />
                  ))}
                </div>

                <p className={styles.quote}>"{item.quote}"</p>

                <div className={styles.divider} aria-hidden="true" />

                <footer className={styles.authorRow}>
                  <span className={styles.avatar} aria-hidden="true">
                    {initials(item.author)}
                  </span>
                  <div className={styles.authorInfo}>
                    <span className={styles.authorName}>
                      {item.author}
                      <BadgeCheck
                        size={14}
                        className={styles.verified}
                        aria-label={t("testimonials.verified")}
                      />
                    </span>
                    <span className={styles.authorRole}>{item.role}</span>
                  </div>
                </footer>
              </article>
            ))}
          </div>

          <p className={styles.dragHint} aria-hidden="true">
            <span className={styles.dragDot} />
            {t("testimonials.drag")}
            <span className={styles.dragDot} />
          </p>
        </div>
      </div>
    </section>
  );
}